package com.UST.SpringBootWebflux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebfluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
